<?php
/**
 * Plugin Update Handler
 * Ermöglicht automatische Updates von einem eigenen Server
 */

if (!defined('ABSPATH')) {
    exit;
}

class MWST_Rechner_Updater {
    
    /**
     * Update-Server URL
     */
    private $update_url;
    
    /**
     * Plugin Slug
     */
    private $plugin_slug;
    
    /**
     * Plugin Basisdatei
     */
    private $plugin_basename;
    
    /**
     * Aktuelle Version
     */
    private $version;
    
    /**
     * Konstruktor
     *
     * @param string $update_url Update-Server URL
     * @param string $plugin_file Plugin-Hauptdatei
     */
    public function __construct($update_url, $plugin_file) {
        $this->update_url = trailingslashit($update_url);
        $this->plugin_basename = plugin_basename($plugin_file);
        $this->plugin_slug = dirname($this->plugin_basename);
        
        // Version aus Plugin-Header auslesen
        if (!function_exists('get_plugin_data')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }
        $plugin_data = get_plugin_data($plugin_file);
        $this->version = $plugin_data['Version'];
        
        // Hooks registrieren
        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_update'));
        add_filter('plugins_api', array($this, 'plugin_info'), 10, 3);
        add_filter('upgrader_post_install', array($this, 'after_install'), 10, 3);
    }
    
    /**
     * Update-Informationen vom Server abrufen
     */
    private function get_remote_info() {
        $request = wp_remote_get(
            $this->update_url . 'mehrwertsteuer_rechner.json',
            array(
                'timeout' => 10,
                'headers' => array(
                    'Accept' => 'application/json'
                )
            )
        );
        
        if (is_wp_error($request)) {
            return false;
        }
        
        $body = wp_remote_retrieve_body($request);
        $data = json_decode($body, true);
        
        if (empty($data)) {
            return false;
        }
        
        return $data;
    }
    
    /**
     * Update-Check durchführen
     */
    public function check_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }
        
        $remote_info = $this->get_remote_info();
        
        if ($remote_info && version_compare($this->version, $remote_info['version'], '<')) {
            $plugin_info = array(
                'slug' => $this->plugin_slug,
                'new_version' => $remote_info['version'],
                'package' => $remote_info['download_url'],
                'tested' => $remote_info['tested'],
                'requires' => $remote_info['requires'],
                'requires_php' => $remote_info['requires_php'],
            );
            
            $transient->response[$this->plugin_basename] = (object) $plugin_info;
        }
        
        return $transient;
    }
    
    /**
     * Plugin-Informationen für Modal bereitstellen
     */
    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information') {
            return $result;
        }
        
        if (!isset($args->slug) || $args->slug !== $this->plugin_slug) {
            return $result;
        }
        
        $remote_info = $this->get_remote_info();
        
        if (!$remote_info) {
            return $result;
        }
        
        $plugin_info = new stdClass();
        $plugin_info->name = $remote_info['name'];
        $plugin_info->slug = $this->plugin_slug;
        $plugin_info->version = $remote_info['version'];
        $plugin_info->author = $remote_info['author'];
        $plugin_info->homepage = $remote_info['homepage'];
        $plugin_info->requires = $remote_info['requires'];
        $plugin_info->tested = $remote_info['tested'];
        $plugin_info->requires_php = $remote_info['requires_php'];
        $plugin_info->download_link = $remote_info['download_url'];
        $plugin_info->sections = array(
            'description' => $remote_info['sections']['description'],
            'changelog' => $remote_info['sections']['changelog'],
            'faq' => isset($remote_info['sections']['faq']) ? $remote_info['sections']['faq'] : '',
        );
        
        if (!empty($remote_info['banners'])) {
            $plugin_info->banners = $remote_info['banners'];
        }
        
        if (!empty($remote_info['icons'])) {
            $plugin_info->icons = $remote_info['icons'];
        }
        
        return $plugin_info;
    }
    
    /**
     * Nach Installation aufräumen
     */
    public function after_install($response, $hook_extra, $result) {
        global $wp_filesystem;
        
        $install_directory = plugin_dir_path($result['destination']);
        $wp_filesystem->move($result['destination'], $install_directory);
        $result['destination'] = $install_directory;
        
        if ($this->plugin_basename === $hook_extra['plugin']) {
            activate_plugin($this->plugin_basename);
        }
        
        return $result;
    }
}